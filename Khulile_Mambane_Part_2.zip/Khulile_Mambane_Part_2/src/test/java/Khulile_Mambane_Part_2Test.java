package com.mycompany.khulile_mambane_part_2;

public class Khulile_Mambane_Part_2Test {
    
    private static int passed = 0;
    private static int failed = 0;
    
    public static void main(String[] args) {
        System.out.println("\n╔════════════════════════════════════════╗");
        System.out.println("║     KHULILE MAMBANE PART 2 TESTS       ║");
        System.out.println("╚════════════════════════════════════════╝\n");
        
        runAllTests();
        
        System.out.println("\n╔════════════════════════════════════════╗");
        System.out.println("║            TEST RESULTS                ║");
        System.out.println("╚════════════════════════════════════════╝");
        System.out.println("✓ Passed: " + passed);
        System.out.println("✗ Failed: " + failed);
        System.out.println("Total: " + (passed + failed));
        
        if (failed == 0) {
            System.out.println("\n🎉 ALL TESTS PASSED! 🎉");
        } else {
            System.out.println("\n⚠️ SOME TESTS FAILED! ⚠️");
        }
    }
    
    static void runAllTests() {
        testPhoneNumberValidation();
        testCharacterLimit();
        testMessageIdGeneration();
        testHashGeneration();
        testMessageCounter();
        testSendOption();
        testDiscardOption();
        testStoreOption();
        testUsernameRegistration();
        testLoginValidation();
    }
    
    static void testPhoneNumberValidation() {
        System.out.println("📞 TEST 1: SA Phone Number Validation");
        
        String valid1 = "0712345678";
        String valid2 = "+27712345678";
        String invalid1 = "08123";
        String invalid2 = "1234567890";
        
        boolean v1 = valid1.matches("^0[678][0-9]{8}$") || valid1.matches("^\\+27[678][0-9]{8}$");
        boolean v2 = valid2.matches("^0[678][0-9]{8}$") || valid2.matches("^\\+27[678][0-9]{8}$");
        boolean i1 = invalid1.matches("^0[678][0-9]{8}$") || invalid1.matches("^\\+27[678][0-9]{8}$");
        boolean i2 = invalid2.matches("^0[678][0-9]{8}$") || invalid2.matches("^\\+27[678][0-9]{8}$");
        
        assertTrue(v1, "Valid SA number: 0712345678");
        assertTrue(v2, "Valid SA number: +27712345678");
        assertFalse(i1, "Invalid number: 08123");
        assertFalse(i2, "Invalid number: 1234567890");
        System.out.println();
    }
    
    static void testCharacterLimit() {
        System.out.println("📏 TEST 2: 250 Character Limit");
        
        String shortMsg = "Hello, this is a short message!";
        assertTrue(shortMsg.length() <= 250, "Short message within limit - SUCCESS");
        
        StringBuilder longMsg = new StringBuilder();
        for (int i = 0; i < 260; i++) {
            longMsg.append("A");
        }
        
        if (longMsg.length() > 250) {
            int extra = longMsg.length() - 250;
            System.out.println("  ✓ FAILURE DETECTED: Message exceeds 250 characters by " + extra);
            passed++;
        } else {
            System.out.println("  ✗ FAIL: Should have detected too long message");
            failed++;
        }
        System.out.println();
    }
    
    static void testMessageIdGeneration() {
        System.out.println("🆔 TEST 3: Message ID Generation");
        
        Khulile_Mambane_Part_2.QuickMessage msg = 
            new Khulile_Mambane_Part_2.QuickMessage(1, "0712345678", "Test message");
        
        String id = msg.getMessageId();
        
        assertNotNull(id, "Message ID generated");
        assertTrue(id.length() <= 10, "Message ID max 10 chars (length: " + id.length() + ")");
        System.out.println("  Message ID: " + id);
        System.out.println();
    }
    
    static void testHashGeneration() {
        System.out.println("🔒 TEST 4: Message Hash Generation");
        
        Khulile_Mambane_Part_2.QuickMessage msg = 
            new Khulile_Mambane_Part_2.QuickMessage(1, "0712345678", "Hello World");
        
        String hash = msg.getMessageHash();
        
        assertNotNull(hash, "Hash generated");
        assertTrue(hash.contains(":"), "Hash contains proper format");
        System.out.println("  Hash: " + hash);
        System.out.println();
    }
    
    static void testMessageCounter() {
        System.out.println("🔢 TEST 5: Message Counter");
        
        int sent = 3;
        int stored = 2;
        int discarded = 1;
        int total = sent + stored + discarded;
        
        assertEquals(3, sent, "Messages sent");
        assertEquals(2, stored, "Messages stored");
        assertEquals(1, discarded, "Messages discarded");
        assertEquals(6, total, "Total messages processed");
        System.out.println();
    }
    
    static void testSendOption() {
        System.out.println("📤 TEST 6: Send Message Option");
        
        String action = "1";
        String result = "";
        
        switch (action) {
            case "1":
                result = "✓ Message sent successfully!";
                break;
            case "2":
                result = "✗ Message discarded.";
                break;
            case "3":
                result = "✓ Message saved to storage!";
                break;
        }
        
        assertEquals("✓ Message sent successfully!", result, "Send option selected");
        System.out.println();
    }
    
    static void testDiscardOption() {
        System.out.println("🗑️ TEST 7: Discard Message Option");
        
        String action = "2";
        String result = "";
        
        switch (action) {
            case "1":
                result = "✓ Message sent successfully!";
                break;
            case "2":
                result = "✗ Message discarded.";
                break;
            case "3":
                result = "✓ Message saved to storage!";
                break;
        }
        
        assertEquals("✗ Message discarded.", result, "Discard option selected");
        System.out.println();
    }
    
    static void testStoreOption() {
        System.out.println("💾 TEST 8: Store Message Option");
        
        String action = "3";
        String result = "";
        
        switch (action) {
            case "1":
                result = "✓ Message sent successfully!";
                break;
            case "2":
                result = "✗ Message discarded.";
                break;
            case "3":
                result = "✓ Message saved to storage!";
                break;
        }
        
        assertEquals("✓ Message saved to storage!", result, "Store option selected");
        System.out.println();
    }
    
    static void testUsernameRegistration() {
        System.out.println("👤 TEST 9: User Registration");
        
        String username = "khulile_user";
        String password = "pass123";
        
        assertNotNull(username, "Username created");
        assertNotNull(password, "Password created");
        assertTrue(username.length() > 0, "Username not empty");
        assertTrue(password.length() > 0, "Password not empty");
        System.out.println("  ✓ Account registered successfully");
        System.out.println();
    }
    
    static void testLoginValidation() {
        System.out.println("🔐 TEST 10: Login Validation");
        
        String registeredUser = "khulile_user";
        String registeredPass = "pass123";
        String enteredUser = "khulile_user";
        String enteredPass = "pass123";
        
        boolean loginSuccess = enteredUser.equals(registeredUser) && enteredPass.equals(registeredPass);
        
        assertTrue(loginSuccess, "Login successful with correct credentials");
        
        enteredUser = "wrong_user";
        loginSuccess = enteredUser.equals(registeredUser) && enteredPass.equals(registeredPass);
        assertFalse(loginSuccess, "Login failed with incorrect username");
        System.out.println();
    }
    
    // ========== ASSERTION METHODS ==========
    
    static void assertTrue(boolean condition, String message) {
        if (condition) {
            System.out.println("  ✓ " + message);
            passed++;
        } else {
            System.out.println("  ✗ " + message);
            failed++;
        }
    }
    
    static void assertFalse(boolean condition, String message) {
        assertTrue(!condition, message);
    }
    
    static void assertEquals(String expected, String actual, String message) {
        if (expected.equals(actual)) {
            System.out.println("  ✓ " + message + ": " + actual);
            passed++;
        } else {
            System.out.println("  ✗ " + message + " - Expected: " + expected + ", Got: " + actual);
            failed++;
        }
    }
    
    static void assertEquals(int expected, int actual, String message) {
        if (expected == actual) {
            System.out.println("  ✓ " + message + ": " + actual);
            passed++;
        } else {
            System.out.println("  ✗ " + message + " - Expected: " + expected + ", Got: " + actual);
            failed++;
        }
    }
    
    static void assertNotNull(Object obj, String message) {
        assertTrue(obj != null, message);
    }
}