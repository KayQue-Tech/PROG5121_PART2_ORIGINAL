package com.mycompany.khulile_mambane_part_2;

import java.util.Scanner;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class Khulile_Mambane_Part_2 {
    
    // Storage arrays for messages
    static List<String> messageIds = new ArrayList<>();
    static List<String> messageHashes = new ArrayList<>();
    static List<String> recipientNumbers = new ArrayList<>();
    static List<String> messageContents = new ArrayList<>();
    static List<String> messageStatus = new ArrayList<>();
    
    static Scanner scanner = new Scanner(System.in);
    
    // User account
    static String registeredUsername = "";
    static String registeredPassword = "";
    static boolean hasAccount = false;
    
    // Message counters
    static int totalSent = 0;
    static int totalStored = 0;
    static int totalDiscarded = 0;
    
    // JSON file name
    static final String JSON_FILE = "khulile_messages.json";
    
    public static void main(String[] args) {
        System.out.println("\n========================================");
        System.out.println("     WELCOME TO QUICK CHAT SYSTEM");
        System.out.println("           Khulile Mambane");
        System.out.println("========================================\n");
        
        boolean isLoggedIn = false;
        
        while (!isLoggedIn) {
            showMainMenu();
            String choice = scanner.nextLine().trim();
            
            switch (choice) {
                case "1":
                    registerAccount();
                    break;
                case "2":
                    if (hasAccount) {
                        isLoggedIn = loginUser();
                    } else {
                        System.out.println("[ERROR] No account found. Please register first.\n");
                    }
                    break;
                case "3":
                    System.out.println("Goodbye! Thanks for using Quick Chat.\n");
                    System.exit(0);
                    break;
                default:
                    System.out.println("[ERROR] Invalid option. Please choose 1, 2, or 3.\n");
            }
        }
        
        startChatSystem();
    }
    
    static void showMainMenu() {
        System.out.println("=== MAIN MENU ===");
        System.out.println("1. Create New Account");
        System.out.println("2. Login to Account");
        System.out.println("3. Exit Application");
        System.out.print("Choose option: ");
    }
    
    static void registerAccount() {
        System.out.println("\n--- REGISTRATION ---");
        System.out.print("Choose username: ");
        registeredUsername = scanner.nextLine().trim();
        System.out.print("Choose password: ");
        registeredPassword = scanner.nextLine().trim();
        hasAccount = true;
        System.out.println("[SUCCESS] Account created successfully!\n");
    }
    
    static boolean loginUser() {
        System.out.println("\n--- LOGIN ---");
        System.out.print("Username: ");
        String username = scanner.nextLine().trim();
        System.out.print("Password: ");
        String password = scanner.nextLine().trim();
        
        if (username.equals(registeredUsername) && password.equals(registeredPassword)) {
            System.out.println("[SUCCESS] Login successful!\n");
            return true;
        } else {
            System.out.println("[ERROR] Invalid username or password.\n");
            return false;
        }
    }
    
    static void startChatSystem() {
        System.out.println("Welcome to Quick Chat Messaging System\n");
        
        int numMessages = 0;
        while (numMessages <= 0) {
            System.out.print("How many messages would you like to create? ");
            try {
                numMessages = Integer.parseInt(scanner.nextLine().trim());
                if (numMessages <= 0) {
                    System.out.println("[ERROR] Please enter a positive number.\n");
                }
            } catch (NumberFormatException e) {
                System.out.println("[ERROR] Invalid number format.\n");
            }
        }
        
        boolean systemRunning = true;
        
        while (systemRunning) {
            showChatMenu();
            String option = scanner.nextLine().trim();
            
            switch (option) {
                case "1":
                    processMessages(numMessages);
                    showSummaryReport();
                    System.out.print("\nPress ENTER to continue or type 'quit' to exit: ");
                    String continueChoice = scanner.nextLine().trim();
                    if (continueChoice.equalsIgnoreCase("quit")) {
                        systemRunning = false;
                    }
                    break;
                case "2":
                    System.out.println("[INFO] Message history feature coming in Part 3!\n");
                    break;
                case "3":
                    System.out.println("Goodbye! Have a great day!\n");
                    systemRunning = false;
                    break;
                default:
                    System.out.println("[ERROR] Invalid option. Choose 1, 2, or 3.\n");
            }
        }
        
        scanner.close();
    }
    
    static void showChatMenu() {
        System.out.println("\n=== QUICK CHAT MENU ===");
        System.out.println("1. Compose & Send Messages");
        System.out.println("2. View Message History");
        System.out.println("3. Exit System");
        System.out.print("Your choice: ");
    }
    
    static void processMessages(int totalMessages) {
        for (int i = 0; i < totalMessages; i++) {
            System.out.println("\n--- MESSAGE " + (i + 1) + " OF " + totalMessages + " ---");
            
            // Get recipient phone number
            String phoneNumber = getValidPhoneNumber();
            
            // Get message content
            String messageText = getValidMessageText();
            
            // Create message object
            QuickMessage msg = new QuickMessage(i + 1, phoneNumber, messageText);
            
            // Show preview
            System.out.println("\n[PREVIEW]");
            System.out.println(msg.getPreview());
            
            // Get user action
            String action = getUserAction();
            System.out.println(action);
            
            // Store based on action
            if (action.equals("✓ Message sent successfully!")) {
                messageIds.add(msg.getMessageId());
                messageHashes.add(msg.getMessageHash());
                recipientNumbers.add(msg.getRecipient());
                messageContents.add(msg.getText());
                messageStatus.add("SENT");
                totalSent++;
            } else if (action.equals("✓ Message saved to storage!")) {
                messageIds.add(msg.getMessageId());
                messageHashes.add(msg.getMessageHash());
                recipientNumbers.add(msg.getRecipient());
                messageContents.add(msg.getText());
                messageStatus.add("STORED");
                totalStored++;
                msg.saveToJson();
            } else if (action.equals("✗ Message discarded.")) {
                totalDiscarded++;
            }
        }
    }
    
    static String getValidPhoneNumber() {
        String phone = "";
        boolean isValid = false;
        
        while (!isValid) {
            System.out.print("Recipient SA number (e.g., 0712345678 or +27712345678): ");
            phone = scanner.nextLine().trim();
            
            String cleanPhone = phone.replaceAll("[\\s-]", "");
            
            if (cleanPhone.matches("^0[678][0-9]{8}$") || cleanPhone.matches("^\\+27[678][0-9]{8}$")) {
                isValid = true;
            } else {
                System.out.println("[ERROR] Invalid SA number! Use 0712345678 or +27712345678\n");
            }
        }
        return phone;
    }
    
    static String getValidMessageText() {
        String message = "";
        boolean isValid = false;
        
        while (!isValid) {
            System.out.print("Enter your message (max 250 characters): ");
            message = scanner.nextLine().trim();
            
            if (message.length() <= 250) {
                isValid = true;
            } else {
                int extra = message.length() - 250;
                System.out.println("[ERROR] Message exceeds 250 characters by " + extra + " chars. Please shorten.\n");
            }
        }
        return message;
    }
    
    static String getUserAction() {
        System.out.println("\n--- MESSAGE OPTIONS ---");
        System.out.println("1. Send Now");
        System.out.println("2. Discard / Delete");
        System.out.println("3. Store for Later (JSON)");
        System.out.print("Choose option (1-3): ");
        
        String choice = scanner.nextLine().trim();
        
        switch (choice) {
            case "1":
                return "✓ Message sent successfully!";
            case "2":
                return "✗ Message discarded.";
            case "3":
                return "✓ Message saved to storage!";
            default:
                System.out.println("[ERROR] Invalid. Message discarded.");
                return "✗ Message discarded.";
        }
    }
    
    static void showSummaryReport() {
        System.out.println("\n╔═══════════════════════════════════════╗");
        System.out.println("║         MESSAGE SUMMARY REPORT        ║");
        System.out.println("╠═══════════════════════════════════════╣");
        System.out.println("║ Messages Sent:     " + formatNumber(totalSent) + "                         ║");
        System.out.println("║ Messages Stored:   " + formatNumber(totalStored) + "                         ║");
        System.out.println("║ Messages Discarded:" + formatNumber(totalDiscarded) + "                         ║");
        System.out.println("║ Total Processed:   " + formatNumber(totalSent + totalStored + totalDiscarded) + "                         ║");
        System.out.println("╚═══════════════════════════════════════╝");
        
        if (!messageIds.isEmpty()) {
            System.out.println("\n--- STORED MESSAGES HISTORY ---");
            for (int i = 0; i < messageIds.size(); i++) {
                System.out.println("\n[" + (i+1) + "]");
                System.out.println("   ID: " + messageIds.get(i));
                System.out.println("   Hash: " + messageHashes.get(i));
                System.out.println("   Recipient: " + recipientNumbers.get(i));
                System.out.println("   Message: " + messageContents.get(i));
                System.out.println("   Status: " + messageStatus.get(i));
            }
        }
    }
    
    static String formatNumber(int num) {
        if (num < 10) {
            return " " + num;
        }
        return String.valueOf(num);
    }
    
    // ========== INNER MESSAGE CLASS ==========
    
    static class QuickMessage {
        private String msgId;
        private int seqNumber;
        private String recipient;
        private String content;
        private String hash;
        
        public QuickMessage(int seq, String phone, String text) {
            this.seqNumber = seq;
            this.recipient = phone;
            this.content = text;
            this.msgId = generateMessageId();
            this.hash = generateHash();
        }
        
        private String generateMessageId() {
            Random rand = new Random();
            long id = 1000000000L + (long)(rand.nextDouble() * 9000000000L);
            return String.valueOf(id).substring(0, 10);
        }
        
        private String generateHash() {
            String prefix = this.msgId.substring(0, 2);
            String[] words = this.content.trim().split("\\s+");
            String firstWord = words.length > 0 ? words[0].toUpperCase() : "";
            String lastWord = words.length > 1 ? words[words.length-1].toUpperCase() : firstWord;
            
            firstWord = firstWord.replaceAll("[^A-Z]", "");
            lastWord = lastWord.replaceAll("[^A-Z]", "");
            
            if (firstWord.length() > 5) firstWord = firstWord.substring(0, 5);
            if (lastWord.length() > 5) lastWord = lastWord.substring(0, 5);
            
            return prefix + ":" + this.seqNumber + ":" + firstWord + lastWord;
        }
        
        public String getPreview() {
            return "Message ID: " + this.msgId + "\n" +
                   "Hash: " + this.hash + "\n" +
                   "To: " + this.recipient + "\n" +
                   "Message: " + this.content;
        }
        
        public void saveToJson() {
            try {
                List<Object> allMessages = new ArrayList<>();
                File file = new File(JSON_FILE);
                
                if (file.exists()) {
                    String existing = new String(Files.readAllBytes(Paths.get(JSON_FILE)));
                    if (!existing.trim().isEmpty()) {
                        // Simple storage - just append
                    }
                }
                
                try (FileWriter writer = new FileWriter(JSON_FILE, true)) {
                    writer.write("{\n");
                    writer.write("  \"message_id\": \"" + this.msgId + "\",\n");
                    writer.write("  \"hash\": \"" + this.hash + "\",\n");
                    writer.write("  \"recipient\": \"" + this.recipient + "\",\n");
                    writer.write("  \"message\": \"" + this.content.replace("\"", "\\\"") + "\",\n");
                    writer.write("  \"timestamp\": \"" + System.currentTimeMillis() + "\"\n");
                    writer.write("}\n");
                }
                
                System.out.println("[INFO] Message saved to: " + file.getAbsolutePath());
                
            } catch (IOException e) {
                System.out.println("[ERROR] Failed to save JSON: " + e.getMessage());
            }
        }
        
        public String getMessageId() { return msgId; }
        public String getMessageHash() { return hash; }
        public String getRecipient() { return recipient; }
        public String getText() { return content; }
    }
}